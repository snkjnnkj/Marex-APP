# Marex-APP

# 派遣员工小程，h5，app的uniApp一套通用性代码，还需vue3的原生web端一套。

